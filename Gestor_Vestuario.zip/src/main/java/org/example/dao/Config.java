package org.example.dao;



public class Config {
   public static final String CAMINHO_BASE = "src/main/java/org/example/database/";

   public static  final String CAMINHO_ITEMS=CAMINHO_BASE + "items.json";
   public static  final String CAMINHO_LAVAGEM=CAMINHO_BASE + "lavagem.json";
   public static  final String CAMINHO_LOOK=CAMINHO_BASE + "look.json";


}
