package org.example.interfaces;

public interface ILavavel {
   void registrarLavagem();
   int getQuantidadeDeLavagens();
}
